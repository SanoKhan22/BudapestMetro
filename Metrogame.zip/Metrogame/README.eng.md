# Budapest Metro Game

**Student Name:** [Your Name Here]  
**Neptun Code:** [Your Neptun Code Here]

## Declaration

I declare that this solution is my own work. I have not copied or used third-party solutions. I have not shared my solution with other students, and I have not made it publicly available. The Student Code of Conduct of Eötvös Loránd University (ELTE Organizational and Operational Regulations, Volume 2, Section 74/C) applies to this assignment.

## Project Description

Budapest Metro Game is a single-player strategy game where players build four metro lines (M1, M2, M3, M4) across a 10×10 grid representing Budapest's metro network. Players draw station cards and strategically connect stations while following placement rules to maximize their score.

## How to Run

1. Open `index.html` in a modern web browser (Chrome 60+, Firefox 60+, Safari 12+, Edge 79+)
2. No build process or server required - runs directly in the browser
3. Ensure JavaScript is enabled

## Technologies Used

- **HTML5** - Semantic markup
- **CSS3** - Styling with CSS Grid and Flexbox
- **Vanilla JavaScript (ES6+)** - No frameworks
- **Local Storage API** - For saving game results

## Code Quality Standards

This project strictly follows these requirements:
- ✅ Uses `const` and `let` only (no `var`)
- ✅ Uses `querySelector` and `querySelectorAll` only (no `getElementById`, etc.)
- ✅ Uses `addEventListener` only (no inline event handlers)
- ✅ No `alert()`, `prompt()`, or `document.write()`
- ✅ No `DOMContentLoaded` event
- ✅ No JavaScript frameworks

## Project Structure

```
budapest-metro-game/
├── index.html              # Main entry point
├── README.eng.md           # This file
│
├── css/
│   ├── styles.css          # Global styles
│   ├── menu.css            # Menu screen
│   ├── game.css            # Game screen
│   └── grid.css            # Grid and stations
│
├── js/
│   ├── constants.js        # Game constants
│   ├── models/             # Data models
│   ├── controllers/        # Game logic
│   ├── views/              # UI rendering
│   ├── utils/              # Helper functions
│   └── app.js              # Application entry
│
├── data/
│   ├── stations.json       # Station data
│   └── lines.json          # Metro line data
│
└── assets/
    └── images/             # SVG icons
```

## Features Implemented

### Minimum Requirements (8 points)

#### Environment
- [x] README.eng.md file filled out (declaration, self-scoring)
- [x] Game created without JavaScript frameworks
- [x] Solution avoids all bad practices (var, getElementById, onclick, etc.)

#### Menu
- [x] Player can enter name before starting
- [x] Start button navigates to game screen
- [x] Menu provides access to game rules and controls

#### Game
- [x] Player name, timer, and current line displayed
- [x] Board and station locations rendered
- [x] Segments can be drawn at 90° or 45° angles

### Core Tasks (12 points)

#### Cards (1.5 points)
- [x] 0.5 points: Random station card drawing (with skip option)
- [x] 0.5 points: Deck contains correct cards (A-B-C-D-Joker for both platform types)
- [x] 0.5 points: Joker card functions correctly

#### Building Segments (5.5 points)
- [x] 0.5 points: Segments only from line end to matching station
- [x] 0.5 points: Joker station (Deák tér) works correctly
- [x] 1.0 point: Segments cannot intersect
- [x] 0.5 points: No parallel segments allowed
- [x] 0.5 points: No loops (cannot revisit stations)
- [x] 1.0 point: Segments cannot pass through other stations
- [x] 1.5 points: Diagonal segments at 45° angles work

#### Rounds (1.5 points)
- [x] 0.5 points: Round order pre-generated and displayed
- [x] 1.0 point: Round ends after 8th card

#### Scoring (3.5 points)

**Round Scoring:**
- [x] 0.5 points: Number of districts covered (PK)
- [x] 0.5 points: Maximum stations in single district (PM)
- [x] 0.5 points: Number of Danube crossings (PD)
- [x] 0.5 points: Round score FP = (PK × PM) + PD

**Game Scoring:**
- [x] 0.5 points: Junction counting (P2, P3, P4)
- [x] 0.5 points: Railway station slider (PP)
- [x] 0.5 points: Final Score = Sum(FP) + PP + (2 × P2) + (5 × P3) + (9 × P4)

### Extra Tasks (5 points)

- [x] 0.5 points: Alternative round-ending (5 cards of same platform type)
- [x] 1.0 point: Local storage for results and leaderboard
- [x] 1.5 points: Switch card functionality
- [x] 2.0 points: Abilities mode (Double Draw, Joker, Switch, Heavy Traffic)

## Total Points: 25/25

## Game Rules Summary

### Objective
Build 4 metro lines to maximize your score through strategic station connections.

### Gameplay
1. Draw station cards (A, B, C, D, Joker, Switch)
2. Build segments connecting stations
3. Follow placement rules
4. Complete 4 rounds (one per metro line)

### Placement Rules
- Segments must be straight (90° or 45° angles)
- Cannot intersect other segments (except at stations)
- Cannot pass through intermediate stations
- Cannot create loops (revisit stations on same line)
- Only one segment between any two stations
- Must match card type to target station type

### Scoring
- **Round Score:** (Districts × Max in District) + Danube Crossings
- **Railway Points:** Slider based on train stations visited
- **Junction Bonus:** 2pts (2 lines), 5pts (3 lines), 9pts (4 lines)
- **Final Score:** Sum of all components

## Known Issues

None at this time.

## Future Improvements

- Add sound effects
- Add animations for segment building
- Add undo functionality
- Add hint system for valid moves
- Add difficulty levels

## Credits

- Game concept based on Budapest metro network
- Developed as part of JavaScript course assignment
- Station and line data provided in starter package

---

**Date Completed:** [Fill in date]  
**Time Spent:** [Fill in hours]
